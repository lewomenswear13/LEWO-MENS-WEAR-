# LEWO MEN'S WEAR

Premium frontend showcase website for LEWO MEN'S WEAR — **WEAR YOUR VOICE.**

## Scope

Frontend-only T-shirt showcase. There is intentionally **no ecommerce functionality**: no cart, checkout, payment, prices, orders, wishlist, or accounts.

## Tech

- React
- TypeScript
- Vite
- Tailwind CSS v4
- Lucide React

## Run locally

```bash
npm install
npm run dev
```

Build:

```bash
npm run build
```

## Assets

Copy the current LEWO image assets into `public/assets/` using these filenames:

- tee-hero.jpg
- tee-white.jpg
- tee-grey.jpg
- tshirt.jpg
- tee-stack.jpg

These are the visual assets used by the current LEWO site.

## Contact

WhatsApp: +91 97263 86410  
Email text: lewomenswear13
