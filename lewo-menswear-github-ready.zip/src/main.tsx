import React,{useEffect,useState} from 'react'
import {createRoot} from 'react-dom/client'
import {ArrowDown,ArrowRight,Expand,Mail,Menu,MessageCircle,X} from 'lucide-react'
import './styles.css'

const WHATSAPP_DISPLAY='+91 97263 86410'
const WHATSAPP_URL='https://wa.me/919726386410'
const EMAIL='lewomenswear13'

type Tee={id:string;no:string;name:string;note:string;img:string}
const TEES:Tee[]=[
 {id:'onyx',no:'01',name:'The Onyx Boxy Tee',note:'Heavyweight cotton, dropped shoulder, boxy silhouette.',img:'/assets/tee-hero.jpg'},
 {id:'chalk',no:'02',name:'The Chalk Tee',note:'Soft off-white, clean ribbed crew, relaxed cut.',img:'/assets/tee-white.jpg'},
 {id:'stone',no:'03',name:'The Stone Tee',note:'Washed grey, dense knit, quietly confident.',img:'/assets/tee-grey.jpg'},
 {id:'jet',no:'04',name:'The Jet Essential',note:'The everyday black tee, refined to the essentials.',img:'/assets/tshirt.jpg'},
 {id:'palette',no:'05',name:'The Palette',note:'Black, white, olive, grey — a full wardrobe of tees.',img:'/assets/tee-stack.jpg'}
]

function LiquidButton({onClick}:{onClick:()=>void}){
 return <button onClick={onClick} className="group inline-flex items-center gap-3 rounded-full border border-white/30 bg-white px-7 py-4 text-xs font-semibold tracking-[.22em] uppercase text-black shadow-[0_0_35px_rgba(255,255,255,.12)] transition hover:scale-[1.02]">
   Explore the collection <ArrowDown className="size-4 transition-transform group-hover:translate-y-1"/>
 </button>
}

function App(){
 const [menu,setMenu]=useState(false),[active,setActive]=useState<Tee|null>(null),[scrolled,setScrolled]=useState(false)
 useEffect(()=>{const f=()=>setScrolled(scrollY>40);f();addEventListener('scroll',f);return()=>removeEventListener('scroll',f)},[])
 useEffect(()=>{document.body.style.overflow=active||menu?'hidden':'';const k=(e:KeyboardEvent)=>e.key==='Escape'&&(setActive(null),setMenu(false));addEventListener('keydown',k);return()=>removeEventListener('keydown',k)},[active,menu])
 const nav=[['Collection','#collection'],['Story','#story'],['Contact','#contact']]
 const scrollTo=(id:string)=>document.getElementById(id)?.scrollIntoView({behavior:'smooth'})
 return <div className="min-h-screen">
  <header className={`sticky top-0 z-40 transition-all ${scrolled?'bg-[#f7f5ef]/90 backdrop-blur border-b border-[#dedbd2]':'bg-[#f7f5ef]'}`}>
   <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5">
    <button className="md:hidden" aria-label="Open menu" onClick={()=>setMenu(true)}><Menu className="size-5"/></button>
    <nav className="hidden gap-8 md:flex">{nav.map(([l,h])=><a key={l} href={h} className="eyebrow hover:opacity-60">{l}</a>)}</nav>
    <a href="#top" className="font-display text-3xl font-semibold tracking-[.25em] md:absolute md:left-1/2 md:-translate-x-1/2">LEWO</a>
    <a href={WHATSAPP_URL} target="_blank" rel="noreferrer" className="flex items-center gap-2 eyebrow hover:opacity-60"><MessageCircle className="size-5"/><span className="hidden md:inline">Say hello</span></a>
   </div>
  </header>

  <section id="top" className="relative h-[88vh] min-h-[560px] overflow-hidden bg-[#171716]">
   <img src="/assets/tee-hero.jpg" alt="LEWO model wearing a black t-shirt" className="absolute inset-0 size-full object-cover object-center"/>
   <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/35 to-transparent"/>
   <div className="relative mx-auto flex h-full max-w-7xl flex-col justify-end px-5 pb-16 text-[#f3f1eb] md:justify-center">
    <p className="eyebrow text-[#c5a46b] reveal">LEWO Men's Wear · The T-Shirt Edit</p>
    <h1 className="font-display mt-4 max-w-2xl text-6xl leading-[.9] reveal md:text-8xl" style={{animationDelay:'.1s'}}>Wear Your <em>Voice.</em></h1>
    <p className="mt-6 max-w-md text-[#f3f1eb]/80 reveal" style={{animationDelay:'.2s'}}>One garment, perfected. Considered cotton, sharp proportions and a silhouette that speaks before you do.</p>
    <div className="mt-8 flex flex-wrap gap-3 reveal" style={{animationDelay:'.3s'}}>
      <LiquidButton onClick={()=>scrollTo('collection')}/>
      <a href="#story" className="inline-flex items-center border border-white/50 px-8 py-4 eyebrow hover:bg-white/10">Our story</a>
    </div>
   </div>
  </section>

  <div className="overflow-hidden border-b border-[#dedbd2] py-4"><div className="marquee flex w-max">{[0,1].map(k=><div key={k} className="flex">{['Wear Your Voice','Designed in India','Premium Cotton','The T-Shirt Edit',"LEWO Men's Wear"].map(t=><span key={t} className="font-display px-8 text-2xl italic text-[#6d6a63]">{t} <span className="text-[#c5a46b]">✦</span></span>)}</div>)}</div></div>

  <section id="collection" className="mx-auto max-w-7xl px-5 py-20 md:py-28">
   <div className="mb-12 max-w-2xl"><p className="eyebrow text-[#c5a46b]">The Collection</p><h2 className="font-display mt-2 text-4xl leading-tight md:text-6xl">Five tees. <em>Zero noise.</em></h2><p className="mt-4 text-[#6d6a63]">Every LEWO t-shirt is built on the same belief: the simplest garment deserves the most attention. Tap any piece to view it up close.</p></div>
   <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-6 md:gap-8">{TEES.map((t,i)=><button key={t.id} onClick={()=>setActive(t)} className={`group text-left ${i<2?'lg:col-span-3':'lg:col-span-2'}`}><div className={`relative overflow-hidden bg-[#e9e6de] ${i<2?'aspect-[4/5]':'aspect-[3/4]'}`}><img src={t.img} alt={t.name} loading="lazy" className="size-full object-cover transition-transform duration-700 group-hover:scale-105"/><span className="absolute left-4 top-4 font-display text-xl text-white mix-blend-difference">{t.no}</span><span className="absolute bottom-4 right-4 grid size-10 place-items-center bg-white/90 opacity-0 transition-opacity group-hover:opacity-100"><Expand className="size-4"/></span></div><h3 className="font-display mt-4 text-2xl">{t.name}</h3><p className="mt-1 text-sm text-[#6d6a63]">{t.note}</p></button>)}</div>
  </section>

  <section id="story" className="bg-[#171716] text-[#f3f1eb]"><div className="mx-auto grid max-w-7xl items-center gap-12 px-5 py-20 md:grid-cols-2 md:py-28"><img src="/assets/tee-stack.jpg" alt="Folded LEWO t-shirts" loading="lazy" className="aspect-[4/5] w-full object-cover"/><div><p className="eyebrow text-[#c5a46b]">About LEWO</p><h2 className="font-display mt-3 text-4xl leading-tight md:text-6xl">Made for men who <em>don't blend in.</em></h2><p className="mt-6 leading-relaxed text-[#f3f1eb]/75">LEWO Men's Wear began with one question: why should the t-shirt — the thing you wear most — be the thing you think about least? We obsess over weight, drape and proportion so every piece feels intentional.</p><p className="mt-4 leading-relaxed text-[#f3f1eb]/75">Designed in India for a generation that knows exactly who it is. No loud logos. Just clothes that let you speak for yourself.</p><div className="mt-10 grid grid-cols-3 gap-6 border-t border-white/15 pt-8">{[['Fabric','Premium cotton'],['Fit','Modern proportions'],['Origin','Designed in India']].map(([k,v])=><div key={k}><p className="eyebrow text-[.6rem] text-[#c5a46b]">{k}</p><p className="font-display mt-2 text-lg md:text-xl">{v}</p></div>)}</div></div></div></section>

  <section className="mx-auto max-w-4xl px-5 py-24 text-center"><p className="eyebrow text-[#c5a46b]">Manifesto</p><p className="font-display mt-6 text-3xl leading-snug md:text-5xl">"Your clothes speak before you do. <em>Make sure they say something true.</em>"</p><p className="eyebrow mt-8 text-[#6d6a63]">— LEWO Men's Wear</p></section>

  <section id="contact" className="border-t border-[#dedbd2]"><div className="mx-auto grid max-w-7xl gap-12 px-5 py-20 md:grid-cols-2 md:py-28"><div><p className="eyebrow text-[#c5a46b]">Contact</p><h2 className="font-display mt-2 text-4xl md:text-6xl">Let's talk.</h2><p className="mt-4 max-w-md text-[#6d6a63]">Questions about the collection, collaborations or press? Reach out — we'd love to hear from you.</p></div><div className="space-y-4"><a href={WHATSAPP_URL} target="_blank" rel="noreferrer" className="group flex items-center justify-between gap-4 border border-[#dedbd2] p-6 hover:border-black"><span className="flex items-center gap-4"><MessageCircle className="size-6 text-[#c5a46b]"/><span><span className="eyebrow block text-[#6d6a63]">WhatsApp</span><span className="font-display text-2xl">{WHATSAPP_DISPLAY}</span></span></span><ArrowRight className="size-5 transition-transform group-hover:translate-x-1"/></a><div className="flex items-center gap-4 border border-[#dedbd2] p-6"><Mail className="size-6 text-[#c5a46b]"/><span><span className="eyebrow block text-[#6d6a63]">Email</span><span className="font-display text-2xl">{EMAIL}</span></span></div></div></div></section>

  <footer className="bg-[#171716] text-[#f3f1eb]"><div className="mx-auto grid max-w-7xl items-end gap-10 px-5 py-16 md:grid-cols-3"><div><p className="font-display text-4xl font-semibold tracking-[.25em]">LEWO</p><p className="eyebrow mt-2 text-[.6rem] text-white/60">LEWO Men's Wear</p><p className="font-display mt-6 text-2xl italic text-[#c5a46b]">Wear Your Voice.</p></div><nav className="flex gap-6 md:justify-center">{nav.map(([l,h])=><a key={l} href={h} className="eyebrow text-[.65rem] hover:text-[#c5a46b]">{l}</a>)}</nav><div className="space-y-2 text-sm md:text-right"><a href={WHATSAPP_URL} target="_blank" rel="noreferrer" className="flex items-center gap-2 hover:text-[#c5a46b] md:justify-end"><MessageCircle className="size-4"/> WhatsApp {WHATSAPP_DISPLAY}</a><p className="flex items-center gap-2 md:justify-end"><Mail className="size-4"/> {EMAIL}</p></div></div><div className="border-t border-white/10 py-6 text-center eyebrow text-[.6rem] text-white/50">© {new Date().getFullYear()} LEWO Men's Wear · Wear Your Voice.</div></footer>

  {menu&&<div className="fixed inset-0 z-50 flex flex-col bg-[#f7f5ef] p-6"><div className="flex items-center justify-between"><span className="font-display text-3xl font-semibold tracking-[.25em]">LEWO</span><button onClick={()=>setMenu(false)}><X className="size-6"/></button></div><nav className="mt-16 flex flex-col gap-6">{nav.map(([l,h])=><a key={l} href={h} onClick={()=>setMenu(false)} className="font-display text-5xl">{l}</a>)}</nav><p className="mt-auto font-display text-2xl italic text-[#c5a46b]">Wear Your Voice.</p></div>}

  {active&&<div className="fixed inset-0 z-50 flex flex-col overflow-y-auto bg-[#171716] text-[#f3f1eb] md:flex-row" role="dialog" aria-modal="true" onClick={()=>setActive(null)}><button className="absolute right-5 top-5 z-10" onClick={()=>setActive(null)}><X className="size-7"/></button><div className="flex min-h-0 flex-1 items-center justify-center p-4 md:p-10" onClick={e=>e.stopPropagation()}><img src={active.img} alt={active.name} className="max-h-full max-w-full object-contain"/></div><div className="p-6 md:w-96 md:self-center md:p-10" onClick={e=>e.stopPropagation()}><p className="eyebrow text-[#c5a46b]">No. {active.no}</p><h3 className="font-display mt-2 text-4xl">{active.name}</h3><p className="mt-4 text-white/75">{active.note}</p><p className="font-display mt-8 text-xl italic text-[#c5a46b]">Wear Your Voice.</p></div></div>}
 </div>
}

createRoot(document.getElementById('root')!).render(<React.StrictMode><App/></React.StrictMode>)
